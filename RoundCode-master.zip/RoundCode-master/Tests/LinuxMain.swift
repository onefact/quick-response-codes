import XCTest

import RoundCodeTests

var tests = [XCTestCaseEntry]()
tests += RoundCodeTests.allTests()
XCTMain(tests)
